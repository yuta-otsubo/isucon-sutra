-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: 127.0.0.1    Database: isuride
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chair_locations`
--

DROP TABLE IF EXISTS `chair_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chair_locations` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL,
  `chair_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子ID',
  `latitude` int NOT NULL COMMENT '経度',
  `longitude` int NOT NULL COMMENT '緯度',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '登録日時',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='椅子の現在位置情報テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chair_locations`
--

LOCK TABLES `chair_locations` WRITE;
/*!40000 ALTER TABLE `chair_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `chair_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chair_models`
--

DROP TABLE IF EXISTS `chair_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chair_models` (
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子モデル名',
  `speed` int NOT NULL COMMENT '移動速度',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='椅子モデルテーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chair_models`
--

LOCK TABLES `chair_models` WRITE;
/*!40000 ALTER TABLE `chair_models` DISABLE KEYS */;
INSERT INTO `chair_models` VALUES ('AeroSeat',3),('Aurora Glow',7),('BalancePro',3),('ComfortBasic',2),('EasySit',2),('ErgoFlex',3),('Infinity Seat',5),('Legacy Chair',7),('LiteLine',2),('LuxeThrone',5),('Phoenix Ultra',7),('ShadowEdition',7),('SitEase',2),('StyleSit',3),('Titanium Line',5),('ZenComfort',5),('アルティマシート X',5),('インフィニティ GEAR V',7),('インペリアルクラフト LUXE',5),('エアシェル ライト',2),('エアフロー EZ',3),('エコシート リジェネレイト',7),('エルゴクレスト II',3),('オブシディアン PRIME',7),('クエストチェア Lite',3),('ゲーミングシート NEXUS',3),('シェルシート ハイブリッド',3),('シャドウバースト M',5),('ステルスシート ROGUE',5),('ストリームギア S1',3),('スピンフレーム 01',2),('スリムライン GX',5),('ゼノバース ALPHA',7),('ゼンバランス EX',5),('タイタンフレーム ULTRA',7),('チェアエース S',2),('ナイトシート ブラックエディション',7),('フォームライン RX',3),('フューチャーステップ VISION',7),('フューチャーチェア CORE',5),('フレックスコンフォート PRO',3),('プレイスタイル Z',3),('プレミアムエアチェア ZETA',5),('プロゲーマーエッジ X1',5),('ベーシックスツール プラス',2),('モーションチェア RISE',5),('リカーブチェア スマート',3),('リラックスシート NEO',2),('リラックス座',2),('ルミナスエアクラウン',7),('ヴァーチェア SUPREME',7),('匠座 PRO LIMITED',7),('匠座（たくみざ）プレミアム',7),('雅楽座',5),('風雅（ふうが）チェア',3);
/*!40000 ALTER TABLE `chair_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chairs`
--

DROP TABLE IF EXISTS `chairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chairs` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子ID',
  `owner_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'オーナーID',
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子の名前',
  `model` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子のモデル',
  `is_active` tinyint(1) NOT NULL COMMENT '配椅子受付中かどうか',
  `access_token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'アクセストークン',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '登録日時',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新日時',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='椅子情報テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chairs`
--

LOCK TABLES `chairs` WRITE;
/*!40000 ALTER TABLE `chairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `user_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT '所有しているユーザーのID',
  `code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'クーポンコード',
  `discount` int NOT NULL COMMENT '割引額',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '付与日時',
  `used_by` varchar(26) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'クーポンが適用されたライドのID',
  PRIMARY KEY (`user_id`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='クーポンテーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners`
--

DROP TABLE IF EXISTS `owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owners` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'オーナーID',
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'オーナー名',
  `access_token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'アクセストークン',
  `chair_register_token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '椅子登録トークン',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '登録日時',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新日時',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `access_token` (`access_token`),
  UNIQUE KEY `chair_register_token` (`chair_register_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='椅子のオーナー情報テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners`
--

LOCK TABLES `owners` WRITE;
/*!40000 ALTER TABLE `owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_tokens`
--

DROP TABLE IF EXISTS `payment_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_tokens` (
  `user_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ユーザーID',
  `token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '決済トークン',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '登録日時',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='決済トークンテーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_tokens`
--

LOCK TABLES `payment_tokens` WRITE;
/*!40000 ALTER TABLE `payment_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ride_statuses`
--

DROP TABLE IF EXISTS `ride_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ride_statuses` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL,
  `ride_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ライドID',
  `status` enum('MATCHING','ENROUTE','PICKUP','CARRYING','ARRIVED','COMPLETED') COLLATE utf8mb4_general_ci NOT NULL COMMENT '状態',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '状態変更日時',
  `app_sent_at` datetime(6) DEFAULT NULL COMMENT 'ユーザーへの状態通知日時',
  `chair_sent_at` datetime(6) DEFAULT NULL COMMENT '椅子への状態通知日時',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='ライドステータスの変更履歴テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ride_statuses`
--

LOCK TABLES `ride_statuses` WRITE;
/*!40000 ALTER TABLE `ride_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ride_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rides`
--

DROP TABLE IF EXISTS `rides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rides` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ライドID',
  `user_id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ユーザーID',
  `chair_id` varchar(26) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '割り当てられた椅子ID',
  `pickup_latitude` int NOT NULL COMMENT '配車位置(経度)',
  `pickup_longitude` int NOT NULL COMMENT '配車位置(緯度)',
  `destination_latitude` int NOT NULL COMMENT '目的地(経度)',
  `destination_longitude` int NOT NULL COMMENT '目的地(緯度)',
  `evaluation` int DEFAULT NULL COMMENT '評価',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '要求日時',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '状態更新日時',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='ライド情報テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rides`
--

LOCK TABLES `rides` WRITE;
/*!40000 ALTER TABLE `rides` DISABLE KEYS */;
/*!40000 ALTER TABLE `rides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '設定名',
  `value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '設定値',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='システム設定テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('payment_gateway_url','http://localhost:12345');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(26) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ユーザーID',
  `username` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ユーザー名',
  `firstname` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '本名(名前)',
  `lastname` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '本名(名字)',
  `date_of_birth` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '生年月日',
  `access_token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'アクセストークン',
  `invitation_code` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '招待トークン',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '登録日時',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新日時',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `access_token` (`access_token`),
  UNIQUE KEY `invitation_code` (`invitation_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='利用者情報テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-24  5:15:31
